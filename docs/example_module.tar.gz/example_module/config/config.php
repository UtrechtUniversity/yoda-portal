<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config["example-item"] = "example value";