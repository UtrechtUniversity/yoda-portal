<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ExampleController extends MY_Controller
{
   
    public function __construct()
    {
        parent::__construct();
        $this->load->library('module', array(__DIR__));
    }

    public function index() {
        $this->load->view('common-start', array(
            'styleIncludes' => array(
                'css/example.css', 
            ),
            'scriptIncludes' => array(
                'js/example.js', 
            ),
            'activeModule'   => $this->module->name(),
            'user' => array(
                'username' => $this->rodsuser->getUsername(),
            ),
        ));
        $this->load->view('example_view.php', $this->data);
        $this->load->view('common-end');
    }
}